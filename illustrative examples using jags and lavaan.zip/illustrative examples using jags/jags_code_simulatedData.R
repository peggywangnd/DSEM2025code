require(rjags)
require(coda)
library(data.table)
library(runjags)
library(lavaan)

# load data
filename <- 'T50N300.csv'
full_data <- read.csv(filename, header=F)
colnames(full_data) <- c("Subject","Day","m","x","y","rep")
data <- full_data[full_data$rep == 1, ]

n <- 300
t <- 50

# specify data
mdata <- data$m
person_data <- data[data$Day == 1,]
constraint <- rep(1,n)
dat <- list("np"=n, "tt"=t, "m"=mdata,
            "x"=person_data$x,
            "y"=person_data$y,
            'cons'=constraint)

# set initial values and seeds
inits = list(
  list(.RNG.name = "base::Wichmann-Hill", .RNG.seed = 123),
  list(.RNG.name = "base::Wichmann-Hill", .RNG.seed = 456))

#### onestep-DSEM ####
# parameters of interest
params <- c("a1","a2","a3","b1","b2","b3","c","ind1","ind2","ind3")
set.seed(123)
out <- run.jags(model='onestep.txt', 
                monitor=params,
                data=dat, 
                inits=inits,
                n.chains=2,
                method="simple", 
                adapt=50000, 
                burnin = 50000,
                sample=1000, 
                thin=10, 
                keep.jags.files=FALSE, 
                tempdir=TRUE)

# onestep-DSEM output
ONESTEP_est <- summary(out)[,"Median"]
ONESTEP_lower <- summary(out)[,"Lower95"]
ONESTEP_upper <- summary(out)[,"Upper95"]


#### two-step (AUX) DSEM ####
## step 1
set.seed(123)
out <- run.jags(model='twostep_AUX.txt', 
                monitor=c("b"), # output the dynamic components
                inits=inits,
                data=dat, 
                n.chains=2,
                method="simple", 
                adapt=50000, 
                burnin = 50000,
                sample=1000, 
                thin=10, 
                keep.jags.files=FALSE, 
                tempdir=TRUE)

samples <- as.mcmc.list(out)
post_draws <- as.matrix(samples)

## step 2
# lavaan mediation model code
model <- '
  # mediator
  mu ~ a1*x
  phi ~ a2*x
  logvare ~ a3*x
  
  # residual covariances among mediators 
  mu ~~ phi 
  mu ~~ logvare 
  phi ~~ logvare

  # outcome
  y ~ b1*mu + b2*phi + b3*logvare + cprime*x

  # indirect, direct, total effects
  ind1 := a1*b1
  ind2 := a2*b2
  ind3 := a3*b3
'


imp <- 50
imp_res <- matrix(rep(0,imp*20), nrow=imp, ncol=20)

for (m in seq(imp)){
  
  # draw every 40th values
  draws_nums <- post_draws[40*m, ]
  draws <- matrix(draws_nums, nrow=n, ncol=5)
  imp_data <- cbind(draws[,1:3], person_data$x, person_data$y)
  colnames(imp_data) <- c("mu","phi","logvare","x","y")
  
  # fit the Level-2 mediation model
  fit <- sem(model, data = imp_data, estimator = "ML")
  para_est <- parameterEstimates(fit)
  para_est <- para_est[para_est$label %in% c("a1","a2","a3","b1","b2","b3","cprime","ind1","ind2","ind3"), 
                       c("est","se")]
  imp_res[m,] <- unlist(para_est) 
  
}

### Rubin's rule
# parameter estimate
TSAUX_est <- colMeans(imp_res[,1:10])
# standard errors and confidence intervals
within_var <- colMeans((imp_res[,11:20])^2)
between_var <- apply(imp_res[,1:10], 2, var)

se_pooled <- sqrt(within_var + (imp+1)/imp*between_var)
TSAUX_lower <- TSAUX_est - 1.96*se_pooled
TSAUX_upper <- TSAUX_est + 1.96*se_pooled



#### two-step (NO-AUX) DSEM ####
## step 1
set.seed(123)
out <- run.jags(model='twostep_NOAUX.txt', 
                monitor=c("b"), # output the dynamic components
                data=dat, 
                inits=inits,
                n.chains=2,
                method="simple", 
                adapt=50000, 
                burnin = 50000,
                sample=1000, 
                thin=10, 
                keep.jags.files=FALSE, 
                tempdir=TRUE)

samples <- as.mcmc.list(out)
post_draws <- as.matrix(samples)

## step 2
# lavaan mediation model code
model <- '
  # mediator
  mu ~ a1*x
  phi ~ a2*x
  logvare ~ a3*x
  
  # residual covariances among mediators 
  mu ~~ phi 
  mu ~~ logvare 
  phi ~~ logvare

  # outcome
  y ~ b1*mu + b2*phi + b3*logvare + cprime*x

  # indirect, direct, total effects
  ind1 := a1*b1
  ind2 := a2*b2
  ind3 := a3*b3
'


imp <- 50
imp_res <- matrix(rep(0,imp*20), nrow=imp, ncol=20)

for (m in seq(imp)){
  
  # draw every 40th values
  draws_nums <- post_draws[40*m, ]
  draws <- matrix(draws_nums, nrow=n, ncol=3)
  imp_data <- cbind(draws, person_data$x, person_data$y)
  colnames(imp_data) <- c("mu","phi","logvare","x","y")
  
  # fit the Level-2 mediation model
  fit <- sem(model, data = imp_data, estimator = "ML")
  para_est <- parameterEstimates(fit)
  para_est <- para_est[para_est$label %in% c("a1","a2","a3","b1","b2","b3","cprime","ind1","ind2","ind3"), 
                       c("est","se")]
  imp_res[m,] <- unlist(para_est) 
  
}

### Rubin's rule
# parameter estimate
TSNOAUX_est <- colMeans(imp_res[,1:10])

# standard errors and confidence intervals
within_var <- colMeans((imp_res[,11:20])^2)
between_var <- apply(imp_res[,1:10], 2, var)

se_pooled <- sqrt(within_var + (imp+1)/imp*between_var)
TSNOAUX_lower <- TSNOAUX_est - 1.96*se_pooled
TSNOAUX_upper <- TSNOAUX_est + 1.96*se_pooled


####### organize the results and output them into a table #####
# keep 3-digits
ONESTEP_est <- round(ONESTEP_est, 3)
ONESTEP_lower <- round(ONESTEP_lower, 3)
ONESTEP_upper <- round(ONESTEP_upper, 3)
TSAUX_est <- round(TSAUX_est, 3)
TSAUX_lower <- round(TSAUX_lower, 3)
TSAUX_upper <- round(TSAUX_upper, 3)
TSNOAUX_est <- round(TSNOAUX_est, 3)
TSNOAUX_lower <- round(TSNOAUX_lower, 3)
TSNOAUX_upper <- round(TSNOAUX_upper, 3)

results <- data.frame("Parameters" = params, 
                      "One-step_DSEM" = paste0(ONESTEP_est, " (", ONESTEP_lower, ", ", ONESTEP_upper, ")"),
                      "Two-step_AUX_DSEM" = paste0(TSAUX_est, " (", TSAUX_lower, ", ", TSAUX_upper, ")"),
                      "Two-step_NOAUX_DSEM" = paste0(TSNOAUX_est, " (", TSNOAUX_lower, ", ", TSNOAUX_upper, ")"))

write.table(results, 'results_table.csv', sep = ',', row.names = F)





