
ite <- 50 # number of imputations
n <- 732 # number of participants

#### we want to remove individuals whose |phi| >= 1 from all imputed datasets

# First, flag the individuals with (|phi| >=1)
ab_list <- matrix(rep(0,n*ite),nrow=n,ncol=ite)
for (j in seq(ite)){
  filename <- paste0('AUX_imp',j,'.csv')
  df <- read.csv(filename, sep = '', header = F)
  colnames(df) <- c('Depr1','Depr2','na','na_lag','phi','logvare','mu','Subject','Time','Timep')
  df_indiv <- df[df$Time == 1, ]
  
  abnormal <- rep(0, n)
  abnormal[which(abs(df_indiv[,'phi']) >= 1)] <- 1
  ab_list[,j] <- abnormal
}

ab_list <- as.data.frame(ab_list)
ab_list[,'abnormal'] <- rowSums(ab_list)

# Then, remove those individuals from all datasets
for (l in seq(ite)){
  filename <- paste0('AUX_imp',l,'.csv')
  df <- read.csv(filename, sep = '', header = F)
  #colnames(df) <- c('age','Depr2','na','na_lag','phi','logvare','mu','Subject','Time')
  colnames(df) <- c('Depr1','Depr2','na','na_lag','phi','logvare','mu','Subject','Time','Timep')

  df_indiv <- df[df$Time == 1, ]
  df_indiv <- df_indiv[which(ab_list$abnormal == 0),]
  
  df_indiv[df_indiv == '*'] <- -999

  ## replace the original file to save space
  # ** Note ** if you want to keep the original imputed datasets, use a different output filename
  write.table(df_indiv, filename, sep = ',', col.names = F, row.names = F)
}
