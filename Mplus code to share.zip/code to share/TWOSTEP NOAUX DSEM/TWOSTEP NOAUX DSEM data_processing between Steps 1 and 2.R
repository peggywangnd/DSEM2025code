
ite <- 50 # number of imputations
n <- 732 # number of participants

#### we want to: 
### 1. merge the auxiliary variables to the imputed datasets
### 2. remove individuals whose |phi| >= 1 from all imputed datasets

# load the auxiliary variables
data <- read.csv('example_data.csv', header = F)
colnames(data) <- c('Subject','day','pa','na','stress','age','gender','availday','Depr1','Depr2')
cov <- data[data$day == 1, c('Subject','Depr1','Depr2')]

# Flag the individuals with (|phi| >=1)
ab_list <- matrix(rep(0,n*ite),nrow=n,ncol=ite)
for (j in seq(ite)){
  filename <- paste0('NOAUX_imp',j,'.csv')
  df <- read.csv(filename, sep = '', header = F)
  colnames(df) <- c('na','na_lag','phi','logvar','mu','Subject','Time','Timep')
  df_indiv <- df[df$Time == 1, ]
  
  abnormal <- rep(0, n)
  abnormal[which(abs(df_indiv[,'phi']) >= 1)] <- 1
  ab_list[,j] <- abnormal
}

ab_list <- as.data.frame(ab_list)
ab_list[,'abnormal'] <- rowSums(ab_list)

# Then, remove those individuals from all datasets
for (l in seq(ite)){
  filename <- paste0('NOAUX_imp',l,'.csv')
  df <- read.csv(filename, sep = '', header = F)
  colnames(df) <- c('na','na_lag','phi','logvar','mu','Subject','Time','Timep')
  
  df_indiv <- df[df$Time == 1, ]
  df_indiv <- df_indiv[which(ab_list$abnormal == 0),]
  
  # merge covariates
  df_final <- merge(df_indiv, cov, by = 'Subject', all.x = F)
  df_final <- df_final[,c('Depr1','Depr2','na','na_lag','phi','logvar','mu','Subject','Time','Timep')] # reorder
  
  # recode the missing values
  df_final[df_final == '*'] <- -999
  

   ## replace the original file to save space
  # ** Note ** if you want to keep the original imputed datasets, use a different output filename
  write.table(df_final, filename, sep = ',', col.names = F, row.names = F)
}



